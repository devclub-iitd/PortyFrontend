self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "43a4de2b046c999d3a1396bf64269662",
    "url": "/PortyDisplay/index.html"
  },
  {
    "revision": "dfbda98774f21461069b",
    "url": "/PortyDisplay/static/css/main.d6bd6bd4.chunk.css"
  },
  {
    "revision": "4383bacfdf88f71f4ec5",
    "url": "/PortyDisplay/static/js/2.02e0d1ad.chunk.js"
  },
  {
    "revision": "e2fc3609d47d90b8cc004bfe15ddf15e",
    "url": "/PortyDisplay/static/js/2.02e0d1ad.chunk.js.LICENSE"
  },
  {
    "revision": "dfbda98774f21461069b",
    "url": "/PortyDisplay/static/js/main.27be6f53.chunk.js"
  },
  {
    "revision": "cd8840b09c7cd5b55498",
    "url": "/PortyDisplay/static/js/runtime-main.f2766a57.js"
  },
  {
    "revision": "fde3c0b1ed24a390fd6180981c7439c8",
    "url": "/PortyDisplay/static/media/award.fde3c0b1.jpg"
  },
  {
    "revision": "73e3ab59751b8dd4bf5c6c8be3335e21",
    "url": "/PortyDisplay/static/media/language.73e3ab59.png"
  },
  {
    "revision": "5d5d9eefa31e5e13a6610d9fa7a283bb",
    "url": "/PortyDisplay/static/media/logo.5d5d9eef.svg"
  },
  {
    "revision": "9e5663bc5a0db818f2eaf47a2567f092",
    "url": "/PortyDisplay/static/media/publish.9e5663bc.jpg"
  },
  {
    "revision": "756b31836ca3dfc446be2b22b4962be9",
    "url": "/PortyDisplay/static/media/skill.756b3183.jpg"
  }
]);